
let cart = [];

function addToCart(item) {
    cart.push(item);
    document.getElementById('cart').innerHTML = cart.map(i => `<li>${i}</li>`).join('');
    updateWhatsAppLink();
}

function updateWhatsAppLink() {
    const phone = '5492271414132';
    const message = `Hola Planeta Trevare! Quiero hacer un pedido:\n\n${cart.map(i => `• ${i}`).join('\n')}\n\nForma de Entrega:\n• Método de Entrega: Delivery\n• Dirección: ...\nForma de Pago:\n• Efectivo`;
    const encoded = encodeURIComponent(message);
    document.getElementById('whatsapp-link').href = `https://wa.me/${phone}?text=${encoded}`;
}
